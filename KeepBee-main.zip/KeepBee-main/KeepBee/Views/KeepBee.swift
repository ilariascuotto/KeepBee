import SwiftUI

@main
struct KeepBee: App {
    var body: some Scene {
        WindowGroup {
            Tabbar()
        }
    }
}

