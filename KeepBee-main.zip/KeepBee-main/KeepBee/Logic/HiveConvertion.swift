//
//  HiveConvertion.swift
//  KeepBee
//
//  Created by Stefano Verrilli on 18/04/22.
//

import Foundation

func ArrayToString(HivesArray: [Hive]) -> String{
    
}
